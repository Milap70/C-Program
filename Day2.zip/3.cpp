#include<iostream>
#include<ctime>
using namespace std;

/*class Distance{
 
     public:
	int feet;
	int inch;

	Distance(int f,int i)
	{
		feet =f;
		inch=i;
	cout << "Feet" << feet << "inches " << inch;
	}

	

};

int main()
{
int f,i;

cin >> f >> i;

Dis d1(f,i);



} */

class Marks{


}
