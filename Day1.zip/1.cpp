#include<iostream>
using namespace std;

int main()
{
	int i;
	cout << "This is output.\n";
	cout<< "Enter a number :";
	cin >>i;

	cout << i <<"square is " << i*i <<"\n";
return 0;

}
